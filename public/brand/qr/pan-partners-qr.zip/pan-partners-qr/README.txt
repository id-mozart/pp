QR-коди Pan&Partners

qr-site  ->  https://pan-partners.agency/
qr-site-uz  ->  https://pan-partners.agency/uz
qr-instagram-tetiana_pan.sales  ->  https://www.instagram.com/tetiana_pan.sales/
qr-instagram-tatiana.pan.sales  ->  https://www.instagram.com/tatiana.pan.sales/

SVG — для друку й макетів, PNG 2000 px — для презентацій і соцмереж.
Навколо коду вже є біле поле (4 модулі) — не обрізайте його. Не перефарбовуйте й не кладіть на темний фон без білої підкладки.
Мінімальний розмір у друці — 2,5 × 2,5 см.
