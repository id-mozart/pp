Pan&Partners — бренд-пак
========================
logo/   — вордмарк: dark (для світлого фону) і light (для темного), SVG + PNG 4800px
fonts/  — фірмові шрифти (Spectral, Inter, JetBrains Mono, Playfair Display) + ролі у README

Кольори, градієнти та правила: https://pan-partners.agency/brand
